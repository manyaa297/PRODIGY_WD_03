const list = document.getElementById('productList');

const fetchProducts = async () => {
  const res = await fetch('http://localhost:5000/api/products');
  const data = await res.json();
  list.innerHTML = data.map(p => `
    <div class="product">
      <h3>${p.name}</h3>
      <img src="${p.image}" alt="${p.name}" />
      <p>${p.description}</p>
      <p>Price: ₹${p.price}</p>
    </div>`).join('');
};

fetchProducts();